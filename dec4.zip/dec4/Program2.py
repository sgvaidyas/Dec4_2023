var1 = 11
var2 = 22
sum = var1 + var2
print("Sum = " , sum)
var1 = "shilpa"
print(var1)