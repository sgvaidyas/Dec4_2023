#Nested conditions
a = 11
b = 2
c = 9
if a>b:
    if a>c:
        print(a, " is greater")
    else:
        print(c, "greater")
else:
    if b>c:
        print(b , " is greater")
    else:
        print(c, " is greater")