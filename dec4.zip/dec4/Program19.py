def fun(a,b):
    print(a,b)

fun(b=888,a=0)