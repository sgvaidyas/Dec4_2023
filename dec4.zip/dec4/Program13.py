#function without any parameters
def insertData():
    id = int(input("Enter the Id = "))
    name = input("Enter the name = ")
    age = int(input("Enter the age = "))

print("Rec 1 ")
insertData()  #function call
print("Rec 2")
insertData()