def add(a,b):
    return (a+b)

def subtract(a,b):
    return a-b

def multiply(a,b):
    return a*b

def division(a,b):
    return a / b

def inputData():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    return a,b

val1,val2 = inputData()
choice = input("1 ADD 2 SUB 3 MUL 4 DIVIDE Enter the choice = ")
match choice:
    case "1":
        print("SUM = ",add(val1,val2))
    case "2":
        print("DIFF = ",subtract(val1,val2))
    case "3":
        print("PROD = ",multiply(val1,val2))
    case "4":
        print("QUOT = ",division(val1,val2))
    case _:
        print("Invalid choice")
