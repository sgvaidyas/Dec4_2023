per = int(input("Per = "))
# >=0 <35  Fail
if per>=0 and per<35:
    print("Fail")
# >=35 <50 Passclass
elif per>=35 and per<50:
    print("PassClass")
elif per>=50 and per<70:
    print("SecondClass")
elif per>=70 and per<=100:
    print("FirstClass")
else:
    print("invalid percentage")
