fruit = input("Enter a fruit = ")
if fruit == "apple":
    print("You chose apple")
elif fruit == "orange":
    print("You chose orange")
elif fruit == "grape":
    print("You chose grape")
else:
    print("the fruit is not in the kitchen")

print("--------------------")