m1 = float(input("Enter marks1 = "))
m2 = float(input("Enter marks2 = "))
m3 = float(input("Enter marks3 = "))
total = m1+m2+m3
avg = total/3
print("----------------------")
print("TOTAL     = ", total)
print("AVG       = ", avg)
print("----------------------")
