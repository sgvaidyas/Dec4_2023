data = str(input("Give your occupation = "))

match data:
    case "Developer":
        print("Developer role is available")
    case "Tester":
        print("Tester role is available")
    case _:
        print("No roles associated with " , data)
