#function without any parameters
def insertData():
    id = int(input("Enter the Id = "))
    name = input("Enter the name = ")
    age = int(input("Enter the age = "))
    display(id,name,age) #function call for display with parameters
def display(id,name,age):  #function definition
    print("ID  = ",id," NAME  = ",name, " AGE = ",age)

print("Rec 1 ")
insertData()  #function call
