a = "shilpa"
b = "7777"
c = a+b
print(c)
a="11"
b="22"
print(a+b)