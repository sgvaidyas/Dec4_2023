def add(a,b,c,d=5,e=10):
    print(a+b+c+d+e)

add(11,22,1,2,3)
add(1,2,3,4)
add(1,2,3)
