num1 = eval(input("Enter val1 = "))
num2 = eval(input("Enter the val2 = "))
print(num1+num2)