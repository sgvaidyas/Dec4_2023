print(' Welcome to python')
print(" This is a sample line ")
print(" hey this is Shilpa's class")
print(' hey this is "Python " class')