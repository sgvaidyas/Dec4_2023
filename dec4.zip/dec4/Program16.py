#function with return
def inputData():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    return a,b

val1,val2 = inputData()
print("val1 = ",val1, " val 2 = ",val2)
