def add():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    res = a+b
    print("SUM = ",res)

def subtract():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    res = a - b
    print("DIFF = ", res)

def multiply():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    res = a * b
    print("PROD = ", res)

def division():
    a = int(input("Enter val1 = "))
    b = int(input("Enter val2 = "))
    res = a / b
    print("QUOT = ", res)

choice = input("1 ADD 2 SUB 3 MUL 4 DIVIDE Enter the choice = ")
match choice:
    case "1":
        add()
    case "2":
        subtract()
    case "3":
        multiply()
    case "4":
        division()
    case _:
        print("Invalid choice")




