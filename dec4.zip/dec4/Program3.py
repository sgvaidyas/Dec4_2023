name = input("Enter the name = ")
print("the name given is ", name)
