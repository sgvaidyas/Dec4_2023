'''
This is a program to calculate
involving functions add,sub,div, mul
'''
num1 = input("Enter the val 1  = ")
num2 = input("Enter the val 2  = ")
num1 = int(num1)
num2 = int(num2)
sum = num1+num2
diff = num1-num2
prod = num1*num2
quot = num1/num2
print("Sum = ",sum," Diff = ", diff," Prod = ", prod, "Quot = ",quot)


