a = int(input("Enter val = "))

if a>=65:
    print("hey u are eligible")
    print("Welcome to WellsFargo")
else:
    print("sorry not eligible")

print("hey this is the end")